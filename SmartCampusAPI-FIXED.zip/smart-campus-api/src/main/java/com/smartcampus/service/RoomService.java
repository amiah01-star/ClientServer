package com.smartcampus.service;

import com.smartcampus.exception.RoomNotEmptyException;
import com.smartcampus.model.Room;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Service class for managing Room entities.
 * 
 * This service provides thread-safe CRUD operations for rooms using
 * ConcurrentHashMap as the underlying data store. All operations are
 * designed to be safe for concurrent access from multiple threads.
 * 
 * Thread Safety:
 * - Uses ConcurrentHashMap for thread-safe storage
 * - Compound operations use synchronized blocks to ensure atomicity
 * - Read operations are lock-free (leveraging ConcurrentHashMap's thread safety)
 * 
 * Design Pattern: Singleton (managed by JAX-RS as a singleton)
 * 
 * @author Ahmet Miah (W2071541)
 * @version 1.0
 */
public class RoomService {

    private static final Logger LOGGER = Logger.getLogger(RoomService.class.getName());

    // Thread-safe in-memory storage for rooms
    // Key: room ID, Value: Room object
    private final Map<String, Room> rooms = new ConcurrentHashMap<>();
    
    // Counter for generating sequential room IDs (if needed)
    private final AtomicLong idCounter = new AtomicLong(1);

    /**
     * Initializes the service with some sample data for demonstration.
     * This is useful for testing the API immediately after startup.
     */
    public RoomService() {
        initializeSampleData();
    }

    /**
     * Creates sample rooms for demonstration purposes.
     */
    private void initializeSampleData() {
        LOGGER.info("Initializing RoomService with sample data...");
        
        // Add some sample rooms
        Room library = new Room("LIB-301", "Library Quiet Study Zone", 50);
        Room lab = new Room("LAB-102", "Computer Science Lab", 30);
        Room lectureHall = new Room("LH-A101", "Main Lecture Hall A", 200);
        
        rooms.put(library.getId(), library);
        rooms.put(lab.getId(), lab);
        rooms.put(lectureHall.getId(), lectureHall);
        
        LOGGER.info(String.format("Initialized %d sample rooms", rooms.size()));
    }

    // ==================== CREATE OPERATIONS ====================

    /**
     * Creates a new room in the system.
     * 
     * Thread Safety: This operation is atomic due to ConcurrentHashMap.put().
     * 
     * @param room The room to create
     * @return The created room (with any server-side modifications)
     * @throws IllegalArgumentException if room is null or room ID is null/empty
     */
    public Room createRoom(Room room) {
        if (room == null) {
            throw new IllegalArgumentException("Room cannot be null");
        }
        if (room.getId() == null || room.getId().trim().isEmpty()) {
            throw new IllegalArgumentException("Room ID cannot be null or empty");
        }
        
        // Check if room already exists
        if (rooms.containsKey(room.getId())) {
            throw new IllegalArgumentException(
                "Room with ID '" + room.getId() + "' already exists");
        }
        
        // Store the room - this is atomic
        rooms.put(room.getId(), room);
        
        LOGGER.log(Level.INFO, "Created room: {0}", room.getId());
        return room;
    }

    // ==================== READ OPERATIONS ====================

    /**
     * Retrieves all rooms in the system.
     * 
     * Thread Safety: Returns a copy of the room list to prevent external
     * modification of internal state.
     * 
     * @return List of all rooms (empty list if none exist)
     */
    public List<Room> getAllRooms() {
        // Return a new ArrayList containing all rooms
        // This prevents external code from modifying our internal map
        return new ArrayList<>(rooms.values());
    }

    /**
     * Retrieves a specific room by its ID.
     * 
     * Thread Safety: Read operation is thread-safe via ConcurrentHashMap.
     * 
     * @param roomId The ID of the room to retrieve
     * @return The Room object, or null if not found
     */
    public Room getRoomById(String roomId) {
        if (roomId == null || roomId.trim().isEmpty()) {
            return null;
        }
        return rooms.get(roomId);
    }

    /**
     * Checks if a room exists in the system.
     * 
     * @param roomId The ID to check
     * @return true if the room exists, false otherwise
     */
    public boolean roomExists(String roomId) {
        return roomId != null && rooms.containsKey(roomId);
    }

    /**
     * Gets the count of rooms in the system.
     * 
     * @return number of rooms
     */
    public int getRoomCount() {
        return rooms.size();
    }

    // ==================== UPDATE OPERATIONS ====================

    /**
     * Updates an existing room.
     * 
     * Thread Safety: This operation is atomic due to ConcurrentHashMap.put().
     * 
     * @param roomId The ID of the room to update
     * @param updatedRoom The updated room data
     * @return The updated room, or null if not found
     * @throws IllegalArgumentException if room doesn't exist
     */
    public Room updateRoom(String roomId, Room updatedRoom) {
        if (!rooms.containsKey(roomId)) {
            throw new IllegalArgumentException("Room with ID '" + roomId + "' not found");
        }
        
        // Preserve the sensor list from the existing room
        Room existingRoom = rooms.get(roomId);
        updatedRoom.setSensorIds(existingRoom.getSensorIds());
        
        // Update the room - this is atomic
        rooms.put(roomId, updatedRoom);
        
        LOGGER.log(Level.INFO, "Updated room: {0}", roomId);
        return updatedRoom;
    }

    /**
     * Adds a sensor ID to a room's sensor list.
     * This is called when a sensor is created and linked to a room.
     * 
     * Thread Safety: Uses synchronized block for compound operation.
     * 
     * @param roomId The room ID
     * @param sensorId The sensor ID to add
     * @return true if added successfully, false if room not found
     */
    public boolean addSensorToRoom(String roomId, String sensorId) {
        Room room = rooms.get(roomId);
        if (room == null) {
            return false;
        }
        
        // Synchronize on the room object for thread-safe modification
        synchronized (room) {
            return room.addSensorId(sensorId);
        }
    }

    /**
     * Removes a sensor ID from a room's sensor list.
     * This is called when a sensor is deleted or moved.
     * 
     * Thread Safety: Uses synchronized block for compound operation.
     * 
     * @param roomId The room ID
     * @param sensorId The sensor ID to remove
     * @return true if removed successfully, false if not found
     */
    public boolean removeSensorFromRoom(String roomId, String sensorId) {
        Room room = rooms.get(roomId);
        if (room == null) {
            return false;
        }
        
        // Synchronize on the room object for thread-safe modification
        synchronized (room) {
            return room.removeSensorId(sensorId);
        }
    }

    // ==================== DELETE OPERATIONS ====================

    /**
     * Deletes a room from the system.
     * 
     * Business Rule: A room cannot be deleted if it still has sensors assigned.
     * This prevents data orphans and maintains referential integrity.
     * 
     * Thread Safety: Uses synchronized block for compound check-and-delete.
     * 
     * @param roomId The ID of the room to delete
     * @throws RoomNotEmptyException if the room still has sensors
     * @throws IllegalArgumentException if room doesn't exist
     */
    public void deleteRoom(String roomId) {
        Room room = rooms.get(roomId);
        
        if (room == null) {
            throw new IllegalArgumentException("Room with ID '" + roomId + "' not found");
        }
        
        // Check if room has sensors - this is the business rule
        if (room.hasSensors()) {
            throw new RoomNotEmptyException(roomId, room.getSensorCount());
        }
        
        // Remove the room - this is atomic
        rooms.remove(roomId);
        
        LOGGER.log(Level.INFO, "Deleted room: {0}", roomId);
    }

    /**
     * Force deletes a room even if it has sensors.
     * This should only be used in administrative scenarios.
     * 
     * @param roomId The ID of the room to delete
     */
    public void forceDeleteRoom(String roomId) {
        rooms.remove(roomId);
        LOGGER.log(Level.WARNING, "Force deleted room: {0}", roomId);
    }

    // ==================== UTILITY METHODS ====================

    /**
     * Clears all rooms from the system.
     * Useful for testing and resetting state.
     */
    public void clearAll() {
        rooms.clear();
        LOGGER.info("Cleared all rooms");
    }

    /**
     * Generates a new unique room ID.
     * 
     * @return A unique room ID
     */
    public String generateRoomId() {
        return "ROOM-" + idCounter.getAndIncrement();
    }
}
