package com.smartcampus.service;

import com.smartcampus.exception.SensorUnavailableException;
import com.smartcampus.model.Sensor;
import com.smartcampus.model.SensorReading;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Service class for managing SensorReading entities.
 * 
 * This service provides thread-safe operations for storing and retrieving
 * sensor readings. Readings are stored per-sensor in a nested structure.
 * 
 * Key Features:
 * - Maintains historical readings for each sensor
 * - Updates sensor's currentValue when new readings are added
 * - Enforces business rules (e.g., cannot add readings to MAINTENANCE sensors)
 * 
 * Thread Safety:
 * - Uses ConcurrentHashMap for thread-safe storage
 * - Each sensor's reading list is synchronized
 * 
 * Design Pattern: Singleton (managed by JAX-RS as a singleton)
 * 
 * @author Ahmet Miah (W2071541)
 * @version 1.0
 */
public class SensorReadingService {

    private static final Logger LOGGER = Logger.getLogger(SensorReadingService.class.getName());

    // Thread-safe storage for readings: Key = sensorId, Value = List of readings
    private final Map<String, List<SensorReading>> readings = new ConcurrentHashMap<>();
    
    // Reference to sensor service for validation and updates
    private final SensorService sensorService;

    /**
     * Creates a new SensorReadingService with a reference to SensorService.
     * 
     * @param sensorService The sensor service for validation and updates
     */
    public SensorReadingService(SensorService sensorService) {
        this.sensorService = sensorService;
    }

    // ==================== CREATE OPERATIONS ====================

    /**
     * Adds a new reading for a sensor.
     * 
     * Business Rules:
     * - The sensor must exist
     * - The sensor must not be in MAINTENANCE status
     * - The reading value must be valid
     * 
     * Side Effect: Updates the sensor's currentValue field.
     * 
     * Thread Safety: Synchronized on the reading list for each sensor.
     * 
     * @param sensorId The ID of the sensor
     * @param reading The reading to add
     * @return The added reading (with generated ID and timestamp)
     * @throws IllegalArgumentException if sensor doesn't exist or reading is invalid
     * @throws SensorUnavailableException if sensor is in MAINTENANCE mode
     */
    public SensorReading addReading(String sensorId, SensorReading reading) {
        // Validate sensor exists
        Sensor sensor = sensorService.getSensorById(sensorId);
        if (sensor == null) {
            throw new IllegalArgumentException("Sensor with ID '" + sensorId + "' not found");
        }
        
        // Business Rule: Cannot add readings to sensors in MAINTENANCE
        if (sensor.isInMaintenance()) {
            throw new SensorUnavailableException(sensor, "new readings");
        }
        
        // Validate reading
        if (reading == null) {
            throw new IllegalArgumentException("Reading cannot be null");
        }
        
        // Ensure reading has ID and timestamp
        if (reading.getId() == null || reading.getId().trim().isEmpty()) {
            reading = new SensorReading(reading.getValue());
        }
        
        // Get or create the reading list for this sensor
        List<SensorReading> sensorReadings = readings.computeIfAbsent(
            sensorId, k -> Collections.synchronizedList(new ArrayList<>()));
        
        // Add the reading (synchronized on the list)
        synchronized (sensorReadings) {
            sensorReadings.add(reading);
        }
        
        // SIDE EFFECT: Update the sensor's currentValue
        sensorService.updateSensorValue(sensorId, reading.getValue());
        
        LOGGER.log(Level.INFO, 
            "Added reading for sensor {0}: value={1}, readingId={2}",
            new Object[]{sensorId, reading.getValue(), reading.getId()});
        
        return reading;
    }

    // ==================== READ OPERATIONS ====================

    /**
     * Retrieves all readings for a sensor.
     * 
     * @param sensorId The sensor ID
     * @return List of readings (empty list if none or sensor not found)
     */
    public List<SensorReading> getReadingsForSensor(String sensorId) {
        List<SensorReading> sensorReadings = readings.get(sensorId);
        if (sensorReadings == null) {
            return new ArrayList<>();
        }
        
        // Return a copy to prevent external modification
        synchronized (sensorReadings) {
            return new ArrayList<>(sensorReadings);
        }
    }

    /**
     * Retrieves the most recent reading for a sensor.
     * 
     * @param sensorId The sensor ID
     * @return The most recent reading, or null if none exist
     */
    public SensorReading getLatestReading(String sensorId) {
        List<SensorReading> sensorReadings = readings.get(sensorId);
        if (sensorReadings == null || sensorReadings.isEmpty()) {
            return null;
        }
        
        synchronized (sensorReadings) {
            // Return the last reading in the list (most recent)
            return sensorReadings.get(sensorReadings.size() - 1);
        }
    }

    /**
     * Gets the count of readings for a sensor.
     * 
     * @param sensorId The sensor ID
     * @return number of readings
     */
    public int getReadingCount(String sensorId) {
        List<SensorReading> sensorReadings = readings.get(sensorId);
        if (sensorReadings == null) {
            return 0;
        }
        
        synchronized (sensorReadings) {
            return sensorReadings.size();
        }
    }

    /**
     * Retrieves readings within a time range.
     * 
     * @param sensorId The sensor ID
     * @param startTime Start timestamp (inclusive)
     * @param endTime End timestamp (inclusive)
     * @return List of readings within the range
     */
    public List<SensorReading> getReadingsInRange(String sensorId, long startTime, long endTime) {
        List<SensorReading> sensorReadings = readings.get(sensorId);
        if (sensorReadings == null) {
            return new ArrayList<>();
        }
        
        synchronized (sensorReadings) {
            return sensorReadings.stream()
                .filter(r -> r.getTimestamp() >= startTime && r.getTimestamp() <= endTime)
                .collect(java.util.stream.Collectors.toList());
        }
    }

    // ==================== DELETE OPERATIONS ====================

    /**
     * Clears all readings for a sensor.
     * 
     * @param sensorId The sensor ID
     * @return true if readings were cleared, false if sensor had no readings
     */
    public boolean clearReadingsForSensor(String sensorId) {
        List<SensorReading> removed = readings.remove(sensorId);
        if (removed != null) {
            LOGGER.log(Level.INFO, "Cleared {0} readings for sensor {1}", 
                new Object[]{removed.size(), sensorId});
            return true;
        }
        return false;
    }

    /**
     * Deletes a specific reading.
     * 
     * @param sensorId The sensor ID
     * @param readingId The reading ID to delete
     * @return true if deleted, false if not found
     */
    public boolean deleteReading(String sensorId, String readingId) {
        List<SensorReading> sensorReadings = readings.get(sensorId);
        if (sensorReadings == null) {
            return false;
        }
        
        synchronized (sensorReadings) {
            boolean removed = sensorReadings.removeIf(r -> r.getId().equals(readingId));
            if (removed) {
                LOGGER.log(Level.INFO, "Deleted reading {0} for sensor {1}", 
                    new Object[]{readingId, sensorId});
            }
            return removed;
        }
    }

    // ==================== UTILITY METHODS ====================

    /**
     * Clears all readings from the system.
     * Useful for testing and resetting state.
     */
    public void clearAll() {
        readings.clear();
        LOGGER.info("Cleared all readings");
    }

    /**
     * Gets the total count of all readings across all sensors.
     * 
     * @return total reading count
     */
    public int getTotalReadingCount() {
        return readings.values().stream()
            .mapToInt(List::size)
            .sum();
    }

    /**
     * Gets all sensor IDs that have readings.
     * 
     * @return List of sensor IDs
     */
    public List<String> getSensorsWithReadings() {
        return new ArrayList<>(readings.keySet());
    }

    /**
     * Calculates the average value of readings for a sensor.
     * 
     * @param sensorId The sensor ID
     * @return The average value, or 0.0 if no readings
     */
    public double getAverageValue(String sensorId) {
        List<SensorReading> sensorReadings = readings.get(sensorId);
        if (sensorReadings == null || sensorReadings.isEmpty()) {
            return 0.0;
        }
        
        synchronized (sensorReadings) {
            return sensorReadings.stream()
                .mapToDouble(SensorReading::getValue)
                .average()
                .orElse(0.0);
        }
    }

    /**
     * Gets the minimum and maximum values for a sensor's readings.
     * 
     * @param sensorId The sensor ID
     * @return double array [min, max], or [0.0, 0.0] if no readings
     */
    public double[] getMinMaxValues(String sensorId) {
        List<SensorReading> sensorReadings = readings.get(sensorId);
        if (sensorReadings == null || sensorReadings.isEmpty()) {
            return new double[]{0.0, 0.0};
        }
        
        synchronized (sensorReadings) {
            double min = sensorReadings.stream()
                .mapToDouble(SensorReading::getValue)
                .min()
                .orElse(0.0);
            double max = sensorReadings.stream()
                .mapToDouble(SensorReading::getValue)
                .max()
                .orElse(0.0);
            return new double[]{min, max};
        }
    }
}
