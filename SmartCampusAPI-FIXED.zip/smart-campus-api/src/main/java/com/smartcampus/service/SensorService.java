package com.smartcampus.service;

import com.smartcampus.exception.LinkedResourceNotFoundException;
import com.smartcampus.model.Sensor;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;

/**
 * Service class for managing Sensor entities.
 * 
 * This service provides thread-safe CRUD operations for sensors using
 * ConcurrentHashMap as the underlying data store. It also handles the
 * relationship between sensors and rooms, ensuring referential integrity.
 * 
 * Thread Safety:
 * - Uses ConcurrentHashMap for thread-safe storage
 * - Compound operations use synchronized blocks where necessary
 * - Read operations are lock-free
 * 
 * Design Pattern: Singleton (managed by JAX-RS as a singleton)
 * 
 * @author Ahmet Miah (W2071541)
 * @version 1.0
 */
public class SensorService {

    private static final Logger LOGGER = Logger.getLogger(SensorService.class.getName());

    // Thread-safe in-memory storage for sensors
    // Key: sensor ID, Value: Sensor object
    private final Map<String, Sensor> sensors = new ConcurrentHashMap<>();
    
    // Counter for generating sequential sensor IDs
    private final AtomicLong idCounter = new AtomicLong(1);
    
    // Reference to room service for validation
    private final RoomService roomService;

    /**
     * Creates a new SensorService with a reference to RoomService.
     * 
     * @param roomService The room service for validation
     */
    public SensorService(RoomService roomService) {
        this.roomService = roomService;
        initializeSampleData();
    }

    /**
     * Creates sample sensors for demonstration purposes.
     */
    private void initializeSampleData() {
        LOGGER.info("Initializing SensorService with sample data...");
        
        // Add some sample sensors linked to the sample rooms
        Sensor tempSensor = new Sensor("TEMP-001", "Temperature", "ACTIVE", 22.5, "LIB-301");
        Sensor co2Sensor = new Sensor("CO2-001", "CO2", "ACTIVE", 450.0, "LIB-301");
        Sensor occupancySensor = new Sensor("OCC-001", "Occupancy", "ACTIVE", 12.0, "LAB-102");
        
        // Store sensors
        sensors.put(tempSensor.getId(), tempSensor);
        sensors.put(co2Sensor.getId(), co2Sensor);
        sensors.put(occupancySensor.getId(), occupancySensor);
        
        // Link sensors to rooms
        roomService.addSensorToRoom("LIB-301", tempSensor.getId());
        roomService.addSensorToRoom("LIB-301", co2Sensor.getId());
        roomService.addSensorToRoom("LAB-102", occupancySensor.getId());
        
        LOGGER.info(String.format("Initialized %d sample sensors", sensors.size()));
    }

    // ==================== CREATE OPERATIONS ====================

    /**
     * Creates a new sensor in the system.
     * 
     * Validation:
     * - Sensor must not be null
     * - Sensor ID must be provided
     * - Room ID must reference an existing room
     * - Sensor type should be valid
     * 
     * Thread Safety: This operation includes validation and is thread-safe.
     * 
     * @param sensor The sensor to create
     * @return The created sensor
     * @throws IllegalArgumentException if sensor data is invalid
     * @throws LinkedResourceNotFoundException if roomId doesn't exist
     */
    public Sensor createSensor(Sensor sensor) {
        // Validate sensor object
        if (sensor == null) {
            throw new IllegalArgumentException("Sensor cannot be null");
        }
        
        // Validate sensor ID
        if (sensor.getId() == null || sensor.getId().trim().isEmpty()) {
            throw new IllegalArgumentException("Sensor ID cannot be null or empty");
        }
        
        // Check if sensor already exists
        if (sensors.containsKey(sensor.getId())) {
            throw new IllegalArgumentException(
                "Sensor with ID '" + sensor.getId() + "' already exists");
        }
        
        // Validate room ID - CRITICAL: Must reference an existing room
        String roomId = sensor.getRoomId();
        if (roomId == null || roomId.trim().isEmpty()) {
            throw new IllegalArgumentException("Room ID cannot be null or empty");
        }
        
        // Check if the referenced room exists
        if (!roomService.roomExists(roomId)) {
            throw new LinkedResourceNotFoundException("Room", "roomId", roomId);
        }
        
        // Validate sensor type
        if (sensor.getType() == null || sensor.getType().trim().isEmpty()) {
            throw new IllegalArgumentException("Sensor type cannot be null or empty");
        }
        
        // Set default status if not provided
        if (sensor.getStatus() == null || sensor.getStatus().trim().isEmpty()) {
            sensor.setStatus(Sensor.STATUS_ACTIVE);
        }
        
        // Validate status value
        if (!Sensor.isValidStatus(sensor.getStatus())) {
            throw new IllegalArgumentException(
                "Invalid sensor status: " + sensor.getStatus() + 
                ". Valid values are: ACTIVE, MAINTENANCE, OFFLINE");
        }
        
        // Store the sensor
        sensors.put(sensor.getId(), sensor);
        
        // Link sensor to room
        roomService.addSensorToRoom(roomId, sensor.getId());
        
        LOGGER.log(Level.INFO, "Created sensor: {0} in room: {1}", 
            new Object[]{sensor.getId(), roomId});
        
        return sensor;
    }

    // ==================== READ OPERATIONS ====================

    /**
     * Retrieves all sensors in the system.
     * 
     * @return List of all sensors
     */
    public List<Sensor> getAllSensors() {
        return new ArrayList<>(sensors.values());
    }

    /**
     * Retrieves sensors filtered by type.
     * 
     * @param type The sensor type to filter by (case-insensitive)
     * @return List of sensors matching the type
     */
    public List<Sensor> getSensorsByType(String type) {
        if (type == null || type.trim().isEmpty()) {
            return getAllSensors();
        }
        
        String normalizedType = type.trim().toLowerCase();
        
        return sensors.values().stream()
            .filter(sensor -> sensor.getType() != null && 
                    sensor.getType().toLowerCase().equals(normalizedType))
            .collect(Collectors.toList());
    }

    /**
     * Retrieves a specific sensor by its ID.
     * 
     * @param sensorId The ID of the sensor to retrieve
     * @return The Sensor object, or null if not found
     */
    public Sensor getSensorById(String sensorId) {
        if (sensorId == null || sensorId.trim().isEmpty()) {
            return null;
        }
        return sensors.get(sensorId);
    }

    /**
     * Checks if a sensor exists in the system.
     * 
     * @param sensorId The ID to check
     * @return true if the sensor exists, false otherwise
     */
    public boolean sensorExists(String sensorId) {
        return sensorId != null && sensors.containsKey(sensorId);
    }

    /**
     * Gets the count of sensors in the system.
     * 
     * @return number of sensors
     */
    public int getSensorCount() {
        return sensors.size();
    }

    /**
     * Gets all sensors in a specific room.
     * 
     * @param roomId The room ID
     * @return List of sensors in that room
     */
    public List<Sensor> getSensorsByRoom(String roomId) {
        return sensors.values().stream()
            .filter(sensor -> roomId.equals(sensor.getRoomId()))
            .collect(Collectors.toList());
    }

    // ==================== UPDATE OPERATIONS ====================

    /**
     * Updates an existing sensor.
     * 
     * @param sensorId The ID of the sensor to update
     * @param updatedSensor The updated sensor data
     * @return The updated sensor
     * @throws IllegalArgumentException if sensor doesn't exist
     */
    public Sensor updateSensor(String sensorId, Sensor updatedSensor) {
        if (!sensors.containsKey(sensorId)) {
            throw new IllegalArgumentException("Sensor with ID '" + sensorId + "' not found");
        }
        
        Sensor existingSensor = sensors.get(sensorId);
        String oldRoomId = existingSensor.getRoomId();
        String newRoomId = updatedSensor.getRoomId();
        
        // If room changed, update room associations
        if (newRoomId != null && !newRoomId.equals(oldRoomId)) {
            // Validate new room exists
            if (!roomService.roomExists(newRoomId)) {
                throw new LinkedResourceNotFoundException("Room", "roomId", newRoomId);
            }
            
            // Remove from old room
            roomService.removeSensorFromRoom(oldRoomId, sensorId);
            
            // Add to new room
            roomService.addSensorToRoom(newRoomId, sensorId);
        }
        
        // Preserve the ID
        updatedSensor.setId(sensorId);
        
        // Update the sensor
        sensors.put(sensorId, updatedSensor);
        
        LOGGER.log(Level.INFO, "Updated sensor: {0}", sensorId);
        return updatedSensor;
    }

    /**
     * Updates the current value of a sensor.
     * This is called when a new reading is added.
     * 
     * @param sensorId The sensor ID
     * @param newValue The new current value
     * @return true if updated successfully, false if sensor not found
     */
    public boolean updateSensorValue(String sensorId, double newValue) {
        Sensor sensor = sensors.get(sensorId);
        if (sensor == null) {
            return false;
        }
        
        // Synchronize on the sensor for thread-safe update
        synchronized (sensor) {
            sensor.setCurrentValue(newValue);
        }
        
        LOGGER.log(Level.FINE, "Updated sensor {0} value to {1}", 
            new Object[]{sensorId, newValue});
        
        return true;
    }

    /**
     * Updates the status of a sensor.
     * 
     * @param sensorId The sensor ID
     * @param newStatus The new status
     * @return true if updated successfully, false if sensor not found or invalid status
     */
    public boolean updateSensorStatus(String sensorId, String newStatus) {
        if (!Sensor.isValidStatus(newStatus)) {
            return false;
        }
        
        Sensor sensor = sensors.get(sensorId);
        if (sensor == null) {
            return false;
        }
        
        synchronized (sensor) {
            sensor.setStatus(newStatus);
        }
        
        LOGGER.log(Level.INFO, "Updated sensor {0} status to {1}", 
            new Object[]{sensorId, newStatus});
        
        return true;
    }

    // ==================== DELETE OPERATIONS ====================

    /**
     * Deletes a sensor from the system.
     * Also removes the sensor reference from its associated room.
     * 
     * @param sensorId The ID of the sensor to delete
     * @throws IllegalArgumentException if sensor doesn't exist
     */
    public void deleteSensor(String sensorId) {
        Sensor sensor = sensors.get(sensorId);
        
        if (sensor == null) {
            throw new IllegalArgumentException("Sensor with ID '" + sensorId + "' not found");
        }
        
        // Remove sensor reference from room
        String roomId = sensor.getRoomId();
        if (roomId != null) {
            roomService.removeSensorFromRoom(roomId, sensorId);
        }
        
        // Remove the sensor
        sensors.remove(sensorId);
        
        LOGGER.log(Level.INFO, "Deleted sensor: {0}", sensorId);
    }

    // ==================== UTILITY METHODS ====================

    /**
     * Clears all sensors from the system.
     * Useful for testing and resetting state.
     */
    public void clearAll() {
        sensors.clear();
        LOGGER.info("Cleared all sensors");
    }

    /**
     * Generates a new unique sensor ID for a given type.
     * 
     * @param type The sensor type
     * @return A unique sensor ID
     */
    public String generateSensorId(String type) {
        String prefix = type != null ? type.substring(0, Math.min(4, type.length())).toUpperCase() : "SENS";
        return prefix + "-" + String.format("%03d", idCounter.getAndIncrement());
    }

    /**
     * Gets all unique sensor types in the system.
     * 
     * @return List of sensor types
     */
    public List<String> getAllSensorTypes() {
        return sensors.values().stream()
            .map(Sensor::getType)
            .distinct()
            .collect(Collectors.toList());
    }
}
