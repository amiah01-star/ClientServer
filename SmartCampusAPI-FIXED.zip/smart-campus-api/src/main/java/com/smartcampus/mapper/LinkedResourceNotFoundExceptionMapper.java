package com.smartcampus.mapper;

import com.smartcampus.exception.LinkedResourceNotFoundException;

import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.ext.ExceptionMapper;
import jakarta.ws.rs.ext.Provider;
import java.util.HashMap;
import java.util.Map;

/**
 * Exception Mapper for LinkedResourceNotFoundException.
 * 
 * This mapper converts LinkedResourceNotFoundException instances into HTTP 422
 * Unprocessable Entity responses with a structured JSON error body.
 * 
 * HTTP 422 Unprocessable Entity is more semantically accurate than 404 in this
 * context because:
 * - The endpoint exists (we found /api/v1/sensors)
 * - The request body is syntactically valid JSON
 * - But the content contains semantic errors (the referenced roomId doesn't exist)
 * 
 * HTTP 422 Unprocessable Entity means the server understands the content type
 * of the request entity, and the syntax is correct, but was unable to process
 * the contained instructions.
 * 
 * This is different from 404 Not Found because:
 * - 404 means the resource at the URL doesn't exist
 * - 422 means the resource at the URL exists, but the request body references
 *   something that doesn't exist
 * 
 * The response includes:
 * - error: The error type
 * - message: Human-readable error description
 * - field: The field containing the invalid reference
 * - rejectedValue: The invalid value that was provided
 * - resourceType: The type of resource that was not found
 * 
 * @author Ahmet Miah (W2071541)
 * @version 1.0
 */
@Provider
public class LinkedResourceNotFoundExceptionMapper implements ExceptionMapper<LinkedResourceNotFoundException> {

    /**
     * Converts a LinkedResourceNotFoundException into an HTTP 422 response.
     * 
     * @param exception The LinkedResourceNotFoundException to map
     * @return A Response object with 422 status and JSON error body
     */
    @Override
    public Response toResponse(LinkedResourceNotFoundException exception) {
        // Build a structured error response
        Map<String, Object> errorResponse = new HashMap<>();
        errorResponse.put("error", "Unprocessable Entity");
        errorResponse.put("statusCode", 422);
        errorResponse.put("message", exception.getDetailedMessage());
        errorResponse.put("field", exception.getFieldName());
        errorResponse.put("rejectedValue", exception.getInvalidValue());
        errorResponse.put("resourceType", exception.getResourceType());
        errorResponse.put("suggestedAction", 
            "Please verify that the " + exception.getResourceType().toLowerCase() + 
            " with " + exception.getFieldName() + "='" + exception.getInvalidValue() + 
            "' exists before making this request.");
        errorResponse.put("documentation", "/api/v1/docs/errors/422");

        return Response
            .status(422) // HTTP 422 Unprocessable Entity
            .entity(errorResponse)
            .type(MediaType.APPLICATION_JSON)
            .build();
    }
}
