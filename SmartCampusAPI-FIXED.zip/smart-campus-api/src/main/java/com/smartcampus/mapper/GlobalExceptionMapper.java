package com.smartcampus.mapper;

import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.ext.ExceptionMapper;
import jakarta.ws.rs.ext.Provider;
import java.time.Instant;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Global Exception Mapper - The "Safety Net" for all unhandled exceptions.
 * 
 * This mapper catches ALL exceptions that are not handled by more specific
 * exception mappers, ensuring that:
 * 1. The API never exposes internal Java stack traces to external clients
 * 2. Every error returns a consistent JSON format
 * 3. All unexpected errors are logged server-side for debugging
 * 
 * SECURITY NOTE: Exposing stack traces to API consumers is a security risk
 * because it reveals:
 * - Internal class and package structures
 * - Method names and line numbers
 * - Framework and library versions
 * - Potential vulnerabilities in the codebase
 * 
 * This information can be used by attackers to:
 * - Identify known vulnerabilities in specific versions
 * - Understand the application's internal architecture
 * - Craft targeted attacks against specific components
 * 
 * This mapper returns HTTP 500 Internal Server Error with a generic message
 * that doesn't reveal any internal implementation details.
 * 
 * @author Ahmet Miah (W2071541)
 * @version 1.0
 */
@Provider
public class GlobalExceptionMapper implements ExceptionMapper<Throwable> {

    private static final Logger LOGGER = Logger.getLogger(GlobalExceptionMapper.class.getName());

    /**
     * Converts any Throwable into a safe HTTP 500 response.
     * 
     * CRITICAL: This method MUST NOT include:
     * - Stack traces
     * - Internal class names
     * - Method names or line numbers
     * - Framework-specific error details
     * 
     * @param exception The Throwable to map
     * @return A Response object with 500 status and safe JSON error body
     */
    @Override
    public Response toResponse(Throwable exception) {
        // Generate a unique error reference ID for server-side log correlation
        String errorReferenceId = UUID.randomUUID().toString();
        
        // Log the FULL exception details server-side (including stack trace)
        // This is safe because it goes to server logs, not the client
        LOGGER.log(Level.SEVERE, 
            String.format("Unhandled exception occurred [Reference: %s]: %s", 
                errorReferenceId, exception.getMessage()), 
            exception);

        // Build a SAFE error response for the client
        // This contains NO internal implementation details
        Map<String, Object> errorResponse = new HashMap<>();
        errorResponse.put("error", "Internal Server Error");
        errorResponse.put("statusCode", 500);
        errorResponse.put("message", 
            "An unexpected error occurred while processing your request. " +
            "Please try again later or contact support if the problem persists.");
        errorResponse.put("errorReferenceId", errorReferenceId);
        errorResponse.put("timestamp", Instant.now().toString());
        errorResponse.put("documentation", "/api/v1/docs/errors/500");

        // Return the safe response
        return Response
            .status(Response.Status.INTERNAL_SERVER_ERROR) // HTTP 500
            .entity(errorResponse)
            .type(MediaType.APPLICATION_JSON)
            .build();
    }
}
