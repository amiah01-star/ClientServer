package com.smartcampus.mapper;

import com.smartcampus.exception.SensorUnavailableException;

import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.ext.ExceptionMapper;
import jakarta.ws.rs.ext.Provider;
import java.util.HashMap;
import java.util.Map;

/**
 * Exception Mapper for SensorUnavailableException.
 * 
 * This mapper converts SensorUnavailableException instances into HTTP 403 Forbidden
 * responses with a structured JSON error body.
 * 
 * HTTP 403 Forbidden is the appropriate status code when:
 * - The request is syntactically correct
 * - The resource exists (the sensor)
 * - But the operation is not allowed due to state constraints
 *   (the sensor is in MAINTENANCE mode and cannot accept readings)
 * 
 * HTTP 403 indicates the server understood the request but refuses to authorize it.
 * In this context, the sensor's current state "forbids" the operation.
 * 
 * This is different from 401 Unauthorized:
 * - 401 means authentication is required or failed
 * - 403 means the client is authenticated (or auth isn't required) but still
 *   cannot perform the action due to permissions or state constraints
 * 
 * The response includes:
 * - error: The error type
 * - message: Human-readable error description
 * - sensorId: The ID of the unavailable sensor
 * - currentStatus: The sensor's current status
 * - attemptedOperation: What operation was attempted
 * - recommendedAction: Guidance for the client
 * 
 * @author Ahmet Miah (W2071541)
 * @version 1.0
 */
@Provider
public class SensorUnavailableExceptionMapper implements ExceptionMapper<SensorUnavailableException> {

    /**
     * Converts a SensorUnavailableException into an HTTP 403 Forbidden response.
     * 
     * @param exception The SensorUnavailableException to map
     * @return A Response object with 403 status and JSON error body
     */
    @Override
    public Response toResponse(SensorUnavailableException exception) {
        // Build a structured error response
        Map<String, Object> errorResponse = new HashMap<>();
        errorResponse.put("error", "Forbidden");
        errorResponse.put("statusCode", 403);
        errorResponse.put("message", exception.getDetailedMessage());
        errorResponse.put("sensorId", exception.getSensorId());
        errorResponse.put("currentStatus", exception.getCurrentStatus());
        errorResponse.put("attemptedOperation", exception.getAttemptedOperation());
        errorResponse.put("recommendedAction", exception.getRecommendedAction());
        errorResponse.put("documentation", "/api/v1/docs/errors/403");

        return Response
            .status(Response.Status.FORBIDDEN) // HTTP 403
            .entity(errorResponse)
            .type(MediaType.APPLICATION_JSON)
            .build();
    }
}
