package com.smartcampus.mapper;

import com.smartcampus.exception.RoomNotEmptyException;

import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.ext.ExceptionMapper;
import jakarta.ws.rs.ext.Provider;
import java.util.HashMap;
import java.util.Map;

/**
 * Exception Mapper for RoomNotEmptyException.
 * 
 * This mapper converts RoomNotEmptyException instances into HTTP 409 Conflict
 * responses with a structured JSON error body.
 * 
 * HTTP 409 Conflict is the appropriate status code when:
 * - The request is syntactically correct
 * - The resource exists
 * - But the operation cannot be completed due to a conflict with the current
 *   state of the resource (the room still has sensors assigned)
 * 
 * The response includes:
 * - error: The error type
 * - message: Human-readable error description
 * - roomId: The ID of the room that couldn't be deleted
 * - sensorCount: Number of sensors still in the room
 * - suggestedAction: Guidance for resolving the conflict
 * 
 * @author Ahmet Miah (W2071541)
 * @version 1.0
 */
@Provider
public class RoomNotEmptyExceptionMapper implements ExceptionMapper<RoomNotEmptyException> {

    /**
     * Converts a RoomNotEmptyException into an HTTP 409 Conflict response.
     * 
     * @param exception The RoomNotEmptyException to map
     * @return A Response object with 409 status and JSON error body
     */
    @Override
    public Response toResponse(RoomNotEmptyException exception) {
        // Build a structured error response
        Map<String, Object> errorResponse = new HashMap<>();
        errorResponse.put("error", "Conflict");
        errorResponse.put("statusCode", 409);
        errorResponse.put("message", exception.getDetailedMessage());
        errorResponse.put("roomId", exception.getRoomId());
        errorResponse.put("sensorCount", exception.getSensorCount());
        errorResponse.put("suggestedAction", 
            "Remove all sensors from this room before attempting deletion. " +
            "You can move sensors to another room or delete them first.");
        errorResponse.put("documentation", "/api/v1/docs/errors/409");

        return Response
            .status(Response.Status.CONFLICT) // HTTP 409
            .entity(errorResponse)
            .type(MediaType.APPLICATION_JSON)
            .build();
    }
}
