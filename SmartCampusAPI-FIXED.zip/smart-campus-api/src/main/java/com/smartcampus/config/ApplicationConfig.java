package com.smartcampus.config;

import com.smartcampus.filter.LoggingFilter;
import com.smartcampus.mapper.GlobalExceptionMapper;
import com.smartcampus.mapper.LinkedResourceNotFoundExceptionMapper;
import com.smartcampus.mapper.RoomNotEmptyExceptionMapper;
import com.smartcampus.mapper.SensorUnavailableExceptionMapper;
import com.smartcampus.resource.DiscoveryResource;
import com.smartcampus.resource.RoomResource;
import com.smartcampus.resource.SensorResource;
import com.smartcampus.service.RoomService;
import com.smartcampus.service.SensorReadingService;
import com.smartcampus.service.SensorService;
import jakarta.ws.rs.ApplicationPath;
import org.glassfish.hk2.utilities.binding.AbstractBinder;
import org.glassfish.jersey.jackson.JacksonFeature;
import org.glassfish.jersey.server.ResourceConfig;

import java.util.logging.Logger;

/**
 * Application Configuration — The JAX-RS Application Entry Point.
 *
 * @ApplicationPath("/api/v1") tells GlassFish to mount Jersey at /api/v1.
 * This is the ONLY place the base path is defined; web.xml contains no
 * Jersey servlet declaration, so there is no path duplication.
 *
 * All API endpoints are therefore reachable at:
 *   http://localhost:8080/smart-campus-api/api/v1/...
 *
 * === JAX-RS Resource Lifecycle (answer to Part 1 Q1) ===
 * By default JAX-RS instantiates a NEW resource class instance for every
 * incoming HTTP request (per-request scope). This means instance fields
 * on resource classes are NOT shared between requests. Services, however,
 * are registered as singletons via HK2 and injected each time — they
 * carry shared state. Because multiple threads can hit the API concurrently,
 * the shared ConcurrentHashMap inside each service provides the thread-safety
 * needed to prevent race conditions and data loss.
 *
 * @author Ahmet Miah (W2071541)
 * @version 1.0
 */
@ApplicationPath("/api/v1")
public class ApplicationConfig extends ResourceConfig {

    private static final Logger LOGGER = Logger.getLogger(ApplicationConfig.class.getName());

    public ApplicationConfig() {

        // ── Resource classes (REST endpoints) ────────────────────────────────
        register(DiscoveryResource.class);
        register(RoomResource.class);
        register(SensorResource.class);
        // SensorReadingResource is instantiated by the sub-resource locator inside
        // SensorResource — it does NOT need to be registered here.

        // ── Exception mappers ─────────────────────────────────────────────────
        register(RoomNotEmptyExceptionMapper.class);          // HTTP 409 Conflict
        register(LinkedResourceNotFoundExceptionMapper.class); // HTTP 422
        register(SensorUnavailableExceptionMapper.class);     // HTTP 403 Forbidden
        register(GlobalExceptionMapper.class);                // HTTP 500 catch-all

        // ── Filters ───────────────────────────────────────────────────────────
        register(LoggingFilter.class);

        // ── JSON support ──────────────────────────────────────────────────────
        register(JacksonFeature.class);

        // ── Singleton services with HK2 dependency injection ──────────────────
        //
        // IMPORTANT: You cannot use `register(new RoomService())` for DI.
        // Calling register(instance) registers the object as a JAX-RS *provider*
        // (mapper/filter), NOT as an injectable binding. When a resource class
        // declares @Inject RoomService, HK2 looks in its binding registry — and
        // finds nothing — so injection silently fails (NullPointerException).
        //
        // The correct approach is AbstractBinder: it tells HK2 *which concrete
        // object* to inject whenever the given type is requested, and as a
        // singleton it shares the same instance (and its in-memory data) across
        // every request.
        //
        final RoomService roomService = new RoomService();
        final SensorService sensorService = new SensorService(roomService);
        final SensorReadingService readingService = new SensorReadingService(sensorService);

        register(new AbstractBinder() {
            @Override
            protected void configure() {
                bind(roomService).to(RoomService.class);
                bind(sensorService).to(SensorService.class);
                bind(readingService).to(SensorReadingService.class);
            }
        });

        LOGGER.info("========================================");
        LOGGER.info("Smart Campus API starting up...");
        LOGGER.info("Student: Ahmet Miah (W2071541)");
        LOGGER.info("Base path: /api/v1");
        LOGGER.info("========================================");
    }
}
