package com.smartcampus.exception;

import com.smartcampus.model.Sensor;

/**
 * Exception thrown when attempting to perform an operation on a sensor
 * that is not available for that operation.
 * 
 * This is typically thrown when trying to add a new reading to a sensor
 * that is in MAINTENANCE mode. Sensors in maintenance are physically
 * disconnected and cannot accept new readings.
 * 
 * This exception maps to HTTP 403 Forbidden, which indicates:
 * - The request was understood and valid
 * - The client is authenticated (if auth were implemented)
 * - But the client does not have permission to perform this action
 *   (in this case, the sensor's current state forbids the operation)
 * 
 * HTTP 403 is appropriate here because the operation is forbidden by
 * business logic/state constraints, not because the resource doesn't exist.
 * 
 * @author Ahmet Miah (W2071541)
 * @version 1.0
 */
public class SensorUnavailableException extends RuntimeException {

    /** The ID of the sensor that is unavailable */
    private final String sensorId;
    
    /** The current status of the sensor */
    private final String currentStatus;
    
    /** The operation that was attempted */
    private final String attemptedOperation;

    /**
     * Creates a new SensorUnavailableException.
     * 
     * @param sensorId The ID of the unavailable sensor
     * @param currentStatus The current status of the sensor
     * @param attemptedOperation The operation that was attempted
     */
    public SensorUnavailableException(String sensorId, String currentStatus, String attemptedOperation) {
        super(String.format(
            "Sensor '%s' is currently in '%s' status and cannot accept %s. " +
            "Please wait until the sensor returns to ACTIVE status.",
            sensorId, currentStatus, attemptedOperation
        ));
        this.sensorId = sensorId;
        this.currentStatus = currentStatus;
        this.attemptedOperation = attemptedOperation;
    }

    /**
     * Creates a new SensorUnavailableException from a Sensor object.
     * 
     * @param sensor The sensor that is unavailable
     * @param attemptedOperation The operation that was attempted
     */
    public SensorUnavailableException(Sensor sensor, String attemptedOperation) {
        this(sensor.getId(), sensor.getStatus(), attemptedOperation);
    }

    /**
     * Creates a new SensorUnavailableException with custom message.
     * 
     * @param sensorId The sensor ID
     * @param currentStatus The current status
     * @param attemptedOperation The attempted operation
     * @param message Custom error message
     */
    public SensorUnavailableException(String sensorId, String currentStatus, String attemptedOperation, String message) {
        super(message);
        this.sensorId = sensorId;
        this.currentStatus = currentStatus;
        this.attemptedOperation = attemptedOperation;
    }

    // ==================== GETTERS ====================

    public String getSensorId() {
        return sensorId;
    }

    public String getCurrentStatus() {
        return currentStatus;
    }

    public String getAttemptedOperation() {
        return attemptedOperation;
    }

    /**
     * Gets a detailed error message suitable for API responses.
     * 
     * @return formatted error message
     */
    public String getDetailedMessage() {
        return String.format(
            "Forbidden: Sensor '%s' is currently '%s'. %s operations are not allowed while the sensor is in this state. " +
            "Current sensor status must be 'ACTIVE' to perform this operation.",
            sensorId, currentStatus, attemptedOperation
        );
    }

    /**
     * Checks if the sensor is in maintenance mode.
     * 
     * @return true if sensor is in MAINTENANCE status
     */
    public boolean isInMaintenance() {
        return Sensor.STATUS_MAINTENANCE.equalsIgnoreCase(currentStatus);
    }

    /**
     * Gets a recommended action for the client.
     * 
     * @return recommended action message
     */
    public String getRecommendedAction() {
        if (isInMaintenance()) {
            return String.format(
                "The sensor '%s' is undergoing maintenance. Please check back later or contact facilities management.",
                sensorId
            );
        }
        return String.format(
            "Please ensure sensor '%s' is in ACTIVE status before attempting %s operations.",
            sensorId, attemptedOperation
        );
    }
}
