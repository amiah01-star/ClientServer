package com.smartcampus.exception;

/**
 * Exception thrown when a request references a resource that does not exist.
 * This is typically used when creating a new resource (like a Sensor) that
 * references another resource (like a Room) via a foreign key relationship.
 * 
 * This exception maps to HTTP 422 Unprocessable Entity, which is more
 * semantically accurate than 404 in this context because:
 * - The endpoint exists (we're posting to /sensors)
 * - The request body is syntactically valid JSON
 * - But the content contains a semantic error (invalid roomId reference)
 * 
 * HTTP 422 indicates the server understands the request and the syntax is correct,
 * but it cannot process the contained instructions due to semantic errors.
 * 
 * @author Ahmet Miah (W2071541)
 * @version 1.0
 */
public class LinkedResourceNotFoundException extends RuntimeException {

    /** The name of the field that contains the invalid reference */
    private final String fieldName;
    
    /** The invalid value that was provided */
    private final String invalidValue;
    
    /** The type of resource that was not found */
    private final String resourceType;

    /**
     * Creates a new LinkedResourceNotFoundException.
     * 
     * @param resourceType The type of resource that was not found (e.g., "Room")
     * @param fieldName The field name in the request (e.g., "roomId")
     * @param invalidValue The invalid value that was provided
     */
    public LinkedResourceNotFoundException(String resourceType, String fieldName, String invalidValue) {
        super(String.format(
            "%s with %s='%s' does not exist. Please provide a valid %s reference.",
            resourceType, fieldName, invalidValue, fieldName
        ));
        this.resourceType = resourceType;
        this.fieldName = fieldName;
        this.invalidValue = invalidValue;
    }

    /**
     * Creates a new LinkedResourceNotFoundException with custom message.
     * 
     * @param resourceType The type of resource
     * @param fieldName The field name
     * @param invalidValue The invalid value
     * @param message Custom error message
     */
    public LinkedResourceNotFoundException(String resourceType, String fieldName, String invalidValue, String message) {
        super(message);
        this.resourceType = resourceType;
        this.fieldName = fieldName;
        this.invalidValue = invalidValue;
    }

    // ==================== GETTERS ====================

    public String getFieldName() {
        return fieldName;
    }

    public String getInvalidValue() {
        return invalidValue;
    }

    public String getResourceType() {
        return resourceType;
    }

    /**
     * Gets a detailed error message suitable for API responses.
     * 
     * @return formatted error message
     */
    public String getDetailedMessage() {
        return String.format(
            "Unprocessable Entity: The %s '%s' referenced in field '%s' does not exist. " +
            "Please verify the reference and try again.",
            resourceType, invalidValue, fieldName
        );
    }

    /**
     * Gets an error response object that can be serialized to JSON.
     * 
     * @return ErrorResponse object
     */
    public ErrorResponse toErrorResponse() {
        return new ErrorResponse(
            "Unprocessable Entity",
            getDetailedMessage(),
            fieldName,
            invalidValue
        );
    }

    /**
     * Inner class representing a structured error response.
     */
    public static class ErrorResponse {
        private final String error;
        private final String message;
        private final String field;
        private final String rejectedValue;

        public ErrorResponse(String error, String message, String field, String rejectedValue) {
            this.error = error;
            this.message = message;
            this.field = field;
            this.rejectedValue = rejectedValue;
        }

        public String getError() {
            return error;
        }

        public String getMessage() {
            return message;
        }

        public String getField() {
            return field;
        }

        public String getRejectedValue() {
            return rejectedValue;
        }
    }
}
