package com.smartcampus.exception;

/**
 * Exception thrown when attempting to delete a Room that still has
 * active Sensors assigned to it.
 * 
 * This exception maps to HTTP 409 Conflict, indicating that the request
 * could not be completed due to a conflict with the current state of the
 * resource (the room is occupied by sensors).
 * 
 * HTTP 409 is the appropriate status because:
 * - The request was understood and syntactically correct
 * - The resource exists (the room)
 * - But the operation cannot be performed due to business logic constraints
 * 
 * @author Ahmet Miah (W2071541)
 * @version 1.0
 */
public class RoomNotEmptyException extends RuntimeException {

    /** The ID of the room that could not be deleted */
    private final String roomId;
    
    /** The number of sensors still assigned to the room */
    private final int sensorCount;

    /**
     * Creates a new RoomNotEmptyException.
     * 
     * @param roomId The ID of the room that cannot be deleted
     * @param sensorCount The number of sensors still in the room
     */
    public RoomNotEmptyException(String roomId, int sensorCount) {
        super(String.format(
            "Room '%s' cannot be deleted because it still has %d sensor(s) assigned. " +
            "Please remove or relocate all sensors before deleting the room.",
            roomId, sensorCount
        ));
        this.roomId = roomId;
        this.sensorCount = sensorCount;
    }

    /**
     * Creates a new RoomNotEmptyException with custom message.
     * 
     * @param roomId The ID of the room
     * @param message Custom error message
     */
    public RoomNotEmptyException(String roomId, String message) {
        super(message);
        this.roomId = roomId;
        this.sensorCount = -1; // Unknown count
    }

    /**
     * Gets the room ID associated with this exception.
     * 
     * @return the room ID
     */
    public String getRoomId() {
        return roomId;
    }

    /**
     * Gets the count of sensors still in the room.
     * 
     * @return sensor count, or -1 if unknown
     */
    public int getSensorCount() {
        return sensorCount;
    }

    /**
     * Gets a detailed error message suitable for API responses.
     * 
     * @return formatted error message
     */
    public String getDetailedMessage() {
        if (sensorCount >= 0) {
            return String.format(
                "Conflict: Room '%s' contains %d active sensor(s). " +
                "Remove all sensors before deleting this room.",
                roomId, sensorCount
            );
        }
        return getMessage();
    }
}
