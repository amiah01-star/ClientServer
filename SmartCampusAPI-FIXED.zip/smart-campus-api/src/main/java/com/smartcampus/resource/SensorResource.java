package com.smartcampus.resource;

import com.smartcampus.model.Sensor;
import com.smartcampus.service.SensorReadingService;
import com.smartcampus.service.SensorService;

import jakarta.inject.Inject;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.UriBuilder;
import java.net.URI;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Sensor Resource - Manages Sensor entities in the Smart Campus API.
 * 
 * This resource provides CRUD operations for sensors at the /api/v1/sensors endpoint.
 * It also implements the sub-resource locator pattern for accessing sensor readings.
 * 
 * Endpoints:
 * - GET    /api/v1/sensors                    - List all sensors (with optional type filter)
 * - POST   /api/v1/sensors                    - Create a new sensor
 * - GET    /api/v1/sensors/{sensorId}         - Get a specific sensor
 * - PUT    /api/v1/sensors/{sensorId}         - Update a sensor
 * - DELETE /api/v1/sensors/{sensorId}         - Delete a sensor
 * - GET    /api/v1/sensors/{sensorId}/readings - Get readings (delegated to SensorReadingResource)
 * - POST   /api/v1/sensors/{sensorId}/readings - Add reading (delegated to SensorReadingResource)
 * 
 * Query Parameters:
 * - type: Filter sensors by type (e.g., ?type=CO2)
 * 
 * @author Ahmet Miah (W2071541)
 * @version 1.0
 */
@Path("/sensors")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class SensorResource {

    private final SensorService sensorService;
    private final SensorReadingService readingService;

    /**
     * Constructor with dependency injection.
     * 
     * @param sensorService The sensor service for business logic
     * @param readingService The reading service for sub-resource delegation
     */
    @Inject
    public SensorResource(SensorService sensorService, SensorReadingService readingService) {
        this.sensorService = sensorService;
        this.readingService = readingService;
    }

    /**
     * Retrieves all sensors, optionally filtered by type.
     * 
     * Query Parameters:
     * - type: Optional filter by sensor type (e.g., Temperature, CO2, Occupancy)
     * 
     * Examples:
     * - GET /api/v1/sensors           - All sensors
     * - GET /api/v1/sensors?type=CO2  - Only CO2 sensors
     * 
     * HTTP: GET /api/v1/sensors[?type={type}]
     * Response: 200 OK with JSON array of sensors
     * 
     * @param type Optional filter by sensor type
     * @return List of sensors
     */
    @GET
    public Response getAllSensors(@QueryParam("type") String type) {
        List<Sensor> sensors;
        
        // Apply filter if type parameter is provided
        if (type != null && !type.trim().isEmpty()) {
            sensors = sensorService.getSensorsByType(type);
        } else {
            sensors = sensorService.getAllSensors();
        }
        
        // Build response with metadata
        Map<String, Object> response = new HashMap<>();
        response.put("count", sensors.size());
        if (type != null && !type.trim().isEmpty()) {
            response.put("filter", "type=" + type);
        }
        response.put("sensors", sensors);
        
        return Response.ok(response).build();
    }

    /**
     * Creates a new sensor.
     * 
     * Validation:
     * - Sensor ID must be unique
     * - Room ID must reference an existing room (422 if not)
     * - Type must be provided
     * 
     * HTTP: POST /api/v1/sensors
     * Request Body: JSON Sensor object
     * Response: 201 Created with Location header, or 400/422
     * 
     * @param sensor The sensor to create
     * @return 201 Created with the new sensor
     */
    @POST
    public Response createSensor(Sensor sensor) {
        // Validate input
        if (sensor == null) {
            return Response.status(Response.Status.BAD_REQUEST)
                .entity(createErrorResponse("Request body cannot be null"))
                .build();
        }
        
        if (sensor.getId() == null || sensor.getId().trim().isEmpty()) {
            return Response.status(Response.Status.BAD_REQUEST)
                .entity(createErrorResponse("Sensor ID is required"))
                .build();
        }
        
        if (sensor.getType() == null || sensor.getType().trim().isEmpty()) {
            return Response.status(Response.Status.BAD_REQUEST)
                .entity(createErrorResponse("Sensor type is required"))
                .build();
        }
        
        if (sensor.getRoomId() == null || sensor.getRoomId().trim().isEmpty()) {
            return Response.status(Response.Status.BAD_REQUEST)
                .entity(createErrorResponse("Room ID is required"))
                .build();
        }
        
        try {
            // Create the sensor
            // LinkedResourceNotFoundException (422) may be thrown here
            Sensor createdSensor = sensorService.createSensor(sensor);
            
            // Build the URI for the new resource
            URI location = UriBuilder.fromResource(SensorResource.class)
                .path(createdSensor.getId())
                .build();
            
            // Build success response
            Map<String, Object> response = new HashMap<>();
            response.put("message", "Sensor created successfully");
            response.put("sensor", createdSensor);
            response.put("location", location.toString());
            
            return Response.created(location)
                .entity(response)
                .build();
                
        } catch (IllegalArgumentException e) {
            return Response.status(Response.Status.BAD_REQUEST)
                .entity(createErrorResponse(e.getMessage()))
                .build();
        }
        // LinkedResourceNotFoundException is handled by LinkedResourceNotFoundExceptionMapper (422)
    }

    /**
     * Retrieves a specific sensor by ID.
     * 
     * HTTP: GET /api/v1/sensors/{sensorId}
     * Response: 200 OK with sensor, or 404 Not Found
     * 
     * @param sensorId The ID of the sensor to retrieve
     * @return The sensor, or 404 if not found
     */
    @GET
    @Path("/{sensorId}")
    public Response getSensor(@PathParam("sensorId") String sensorId) {
        Sensor sensor = sensorService.getSensorById(sensorId);
        
        if (sensor == null) {
            return Response.status(Response.Status.NOT_FOUND)
                .entity(createErrorResponse("Sensor with ID '" + sensorId + "' not found"))
                .build();
        }
        
        return Response.ok(sensor).build();
    }

    /**
     * Updates an existing sensor.
     * 
     * HTTP: PUT /api/v1/sensors/{sensorId}
     * Request Body: JSON Sensor object with updated fields
     * Response: 200 OK with updated sensor, or 404 Not Found
     * 
     * @param sensorId The ID of the sensor to update
     * @param updatedSensor The updated sensor data
     * @return The updated sensor
     */
    @PUT
    @Path("/{sensorId}")
    public Response updateSensor(@PathParam("sensorId") String sensorId, Sensor updatedSensor) {
        // Validate input
        if (updatedSensor == null) {
            return Response.status(Response.Status.BAD_REQUEST)
                .entity(createErrorResponse("Request body cannot be null"))
                .build();
        }
        
        // Check if sensor exists
        Sensor existingSensor = sensorService.getSensorById(sensorId);
        if (existingSensor == null) {
            return Response.status(Response.Status.NOT_FOUND)
                .entity(createErrorResponse("Sensor with ID '" + sensorId + "' not found"))
                .build();
        }
        
        // Preserve the ID from the path
        updatedSensor.setId(sensorId);
        
        try {
            Sensor result = sensorService.updateSensor(sensorId, updatedSensor);
            
            Map<String, Object> response = new HashMap<>();
            response.put("message", "Sensor updated successfully");
            response.put("sensor", result);
            
            return Response.ok(response).build();
            
        } catch (IllegalArgumentException e) {
            return Response.status(Response.Status.BAD_REQUEST)
                .entity(createErrorResponse(e.getMessage()))
                .build();
        }
        // LinkedResourceNotFoundException is handled by LinkedResourceNotFoundExceptionMapper (422)
    }

    /**
     * Deletes a sensor.
     * 
     * HTTP: DELETE /api/v1/sensors/{sensorId}
     * Response: 204 No Content on success, or 404 Not Found
     * 
     * @param sensorId The ID of the sensor to delete
     * @return 204 No Content on success
     */
    @DELETE
    @Path("/{sensorId}")
    public Response deleteSensor(@PathParam("sensorId") String sensorId) {
        // Check if sensor exists first (for proper 404)
        Sensor sensor = sensorService.getSensorById(sensorId);
        if (sensor == null) {
            return Response.status(Response.Status.NOT_FOUND)
                .entity(createErrorResponse("Sensor with ID '" + sensorId + "' not found"))
                .build();
        }
        
        try {
            // Delete the sensor
            sensorService.deleteSensor(sensorId);
            
            // Also clean up any readings for this sensor
            readingService.clearReadingsForSensor(sensorId);
            
            // Success - return 204 No Content
            return Response.noContent().build();
            
        } catch (IllegalArgumentException e) {
            return Response.status(Response.Status.NOT_FOUND)
                .entity(createErrorResponse(e.getMessage()))
                .build();
        }
    }

    /**
     * SUB-RESOURCE LOCATOR PATTERN
     * 
     * This method returns a new SensorReadingResource instance that handles
     * all sub-resource requests for /api/v1/sensors/{sensorId}/readings
     * 
     * Benefits of this pattern:
     * 1. Separation of concerns - reading logic is in its own class
     * 2. Better code organization and maintainability
     * 3. The sub-resource has access to the sensorId from the path
     * 4. Supports deep nesting without massive controller classes
     * 
     * HTTP: All methods to /api/v1/sensors/{sensorId}/readings
     * Delegated to: SensorReadingResource
     * 
     * @param sensorId The sensor ID from the path
     * @return SensorReadingResource instance for handling sub-requests
     */
    @Path("/{sensorId}/readings")
    public SensorReadingResource getSensorReadingResource(@PathParam("sensorId") String sensorId) {
        // Return a new instance of the sub-resource
        // The sensorId is passed to the constructor for context
        return new SensorReadingResource(sensorId, sensorService, readingService);
    }

    /**
     * Gets the count of sensors in the system.
     * 
     * HTTP: GET /api/v1/sensors/count
     * Response: 200 OK with count
     * 
     * @return Sensor count
     */
    @GET
    @Path("/count")
    public Response getSensorCount() {
        Map<String, Object> response = new HashMap<>();
        response.put("count", sensorService.getSensorCount());
        
        return Response.ok(response).build();
    }

    /**
     * Gets all available sensor types.
     * 
     * HTTP: GET /api/v1/sensors/types
     * Response: 200 OK with list of types
     * 
     * @return List of sensor types
     */
    @GET
    @Path("/types")
    public Response getSensorTypes() {
        Map<String, Object> response = new HashMap<>();
        response.put("types", sensorService.getAllSensorTypes());
        
        return Response.ok(response).build();
    }

    /**
     * Helper method to create a standardized error response.
     * 
     * @param message The error message
     * @return Map containing error details
     */
    private Map<String, Object> createErrorResponse(String message) {
        Map<String, Object> error = new HashMap<>();
        error.put("error", "Bad Request");
        error.put("message", message);
        return error;
    }
}
