package com.smartcampus.resource;

import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

import java.time.Instant;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Discovery Resource — The API Entry Point.
 *
 * GET /api/v1  returns essential metadata about the API:
 *   - versioning info
 *   - administrative contact
 *   - a "resources" map of primary collections (HATEOAS)
 *
 * === Why HATEOAS matters (answer to Part 1 Q2) ===
 * HATEOAS (Hypermedia as the Engine of Application State) embeds navigation
 * links directly in API responses rather than expecting clients to construct
 * URLs from out-of-band documentation. Benefits:
 *  1. Clients are decoupled from URL structure — if a path changes, the server
 *     updates the link; clients that follow links automatically adapt.
 *  2. Self-documenting — developers exploring the API can discover every
 *     available action without reading a separate document.
 *  3. Reduces "URL coupling" bugs caused by hard-coded paths in client code.
 *
 * Endpoint: GET /api/v1
 *
 * @author Ahmet Miah (W2071541)
 * @version 1.0
 */
@Path("/")
public class DiscoveryResource {

    private static final String API_VERSION     = "1.0.0";
    private static final String API_NAME        = "Smart Campus API";
    private static final String API_DESCRIPTION = "RESTful API for Smart Campus Sensor and Room Management";
    private static final String ADMIN_NAME      = "Ahmet Miah";
    private static final String ADMIN_EMAIL     = "w2071541@westminster.ac.uk";
    private static final String STUDENT_ID      = "W2071541";
    private static final String ORGANISATION    = "University of Westminster";

    /**
     * Returns API discovery / metadata information.
     *
     * Response shape (all keys required by the spec):
     * {
     *   "name":        "Smart Campus API",
     *   "version":     "1.0.0",
     *   "description": "...",
     *   "contact": { "name": "...", "email": "...", ... },
     *   "resources": {
     *       "rooms":   "/api/v1/rooms",
     *       "sensors": "/api/v1/sensors"
     *   },
     *   "status":    "operational",
     *   "timestamp": "<ISO-8601>"
     * }
     *
     * @return HTTP 200 OK with JSON discovery document
     */
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getDiscoveryInfo() {

        // LinkedHashMap preserves insertion order for clean JSON output
        Map<String, Object> body = new LinkedHashMap<>();

        body.put("name",        API_NAME);
        body.put("version",     API_VERSION);
        body.put("description", API_DESCRIPTION);
        body.put("basePath",    "/api/v1");
        body.put("status",      "operational");
        body.put("timestamp",   Instant.now().toString());

        // Administrative contact details
        Map<String, String> contact = new LinkedHashMap<>();
        contact.put("name",         ADMIN_NAME);
        contact.put("email",        ADMIN_EMAIL);
        contact.put("studentId",    STUDENT_ID);
        contact.put("organisation", ORGANISATION);
        body.put("contact", contact);

        // Primary resource collection map — the "resources" key is what the
        // spec explicitly names: "rooms" -> "/api/v1/rooms"
        Map<String, String> resources = new LinkedHashMap<>();
        resources.put("rooms",   "/api/v1/rooms");
        resources.put("sensors", "/api/v1/sensors");
        body.put("resources", resources);

        // HATEOAS _links (richer navigation for advanced clients)
        Map<String, Object> links = new LinkedHashMap<>();
        links.put("self",    link("GET", "/api/v1",         "API discovery"));
        links.put("rooms",   link("GET", "/api/v1/rooms",   "List all rooms"));
        links.put("sensors", link("GET", "/api/v1/sensors", "List all sensors"));
        links.put("health",  link("GET", "/api/v1/health",  "Health check"));
        body.put("_links", links);

        return Response.ok(body).build();
    }

    /**
     * Simple health-check endpoint.
     *
     * @return HTTP 200 OK with current server status
     */
    @GET
    @Path("/health")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getHealth() {
        Map<String, Object> health = new LinkedHashMap<>();
        health.put("status",    "healthy");
        health.put("timestamp", Instant.now().toString());
        return Response.ok(health).build();
    }

    // ── helpers ──────────────────────────────────────────────────────────────

    private Map<String, String> link(String method, String href, String description) {
        Map<String, String> m = new LinkedHashMap<>();
        m.put("href",        href);
        m.put("method",      method);
        m.put("description", description);
        return m;
    }
}
