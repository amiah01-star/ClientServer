package com.smartcampus.resource;

import com.smartcampus.model.Room;
import com.smartcampus.service.RoomService;

import jakarta.inject.Inject;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.UriBuilder;
import java.net.URI;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Room Resource - Manages Room entities in the Smart Campus API.
 * 
 * This resource provides CRUD operations for rooms at the /api/v1/rooms path.
 * It handles room creation, retrieval, update, and deletion with proper
 * business logic enforcement.
 * 
 * Endpoints:
 * - GET    /api/v1/rooms       - List all rooms
 * - POST   /api/v1/rooms       - Create a new room
 * - GET    /api/v1/rooms/{id}  - Get a specific room
 * - PUT    /api/v1/rooms/{id}  - Update a room
 * - DELETE /api/v1/rooms/{id}  - Delete a room (with safety check)
 * 
 * Business Rules:
 * - A room cannot be deleted if it still has sensors assigned (409 Conflict)
 * 
 * @author Ahmet Miah (W2071541)
 * @version 1.0
 */
@Path("/rooms")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class RoomResource {

    private final RoomService roomService;

    /**
     * Constructor with dependency injection.
     * 
     * @param roomService The room service for business logic
     */
    @Inject
    public RoomResource(RoomService roomService) {
        this.roomService = roomService;
    }

    /**
     * Retrieves all rooms in the system.
     * 
     * Returns a complete list of all rooms with their full details.
     * For large systems, consider implementing pagination.
     * 
     * HTTP: GET /api/v1/rooms
     * Response: 200 OK with JSON array of rooms
     * 
     * @return List of all rooms
     */
    @GET
    public Response getAllRooms() {
        List<Room> rooms = roomService.getAllRooms();
        
        // Build response with metadata
        Map<String, Object> response = new HashMap<>();
        response.put("count", rooms.size());
        response.put("rooms", rooms);
        
        return Response.ok(response).build();
    }

    /**
     * Creates a new room in the system.
     * 
     * The room ID must be unique. If successful, returns 201 Created
     * with a Location header pointing to the new resource.
     * 
     * HTTP: POST /api/v1/rooms
     * Request Body: JSON Room object
     * Response: 201 Created with Location header, or 400 Bad Request
     * 
     * @param room The room to create
     * @return 201 Created with the new room
     */
    @POST
    public Response createRoom(Room room) {
        // Validate input
        if (room == null) {
            return Response.status(Response.Status.BAD_REQUEST)
                .entity(createErrorResponse("Request body cannot be null"))
                .build();
        }
        
        if (room.getId() == null || room.getId().trim().isEmpty()) {
            return Response.status(Response.Status.BAD_REQUEST)
                .entity(createErrorResponse("Room ID is required"))
                .build();
        }
        
        if (room.getName() == null || room.getName().trim().isEmpty()) {
            return Response.status(Response.Status.BAD_REQUEST)
                .entity(createErrorResponse("Room name is required"))
                .build();
        }
        
        if (room.getCapacity() <= 0) {
            return Response.status(Response.Status.BAD_REQUEST)
                .entity(createErrorResponse("Room capacity must be greater than 0"))
                .build();
        }
        
        try {
            // Create the room
            Room createdRoom = roomService.createRoom(room);
            
            // Build the URI for the new resource
            URI location = UriBuilder.fromResource(RoomResource.class)
                .path(createdRoom.getId())
                .build();
            
            // Build success response
            Map<String, Object> response = new HashMap<>();
            response.put("message", "Room created successfully");
            response.put("room", createdRoom);
            response.put("location", location.toString());
            
            return Response.created(location)
                .entity(response)
                .build();
                
        } catch (IllegalArgumentException e) {
            return Response.status(Response.Status.BAD_REQUEST)
                .entity(createErrorResponse(e.getMessage()))
                .build();
        }
    }

    /**
     * Retrieves a specific room by ID.
     * 
     * HTTP: GET /api/v1/rooms/{roomId}
     * Response: 200 OK with room, or 404 Not Found
     * 
     * @param roomId The ID of the room to retrieve
     * @return The room, or 404 if not found
     */
    @GET
    @Path("/{roomId}")
    public Response getRoom(@PathParam("roomId") String roomId) {
        Room room = roomService.getRoomById(roomId);
        
        if (room == null) {
            return Response.status(Response.Status.NOT_FOUND)
                .entity(createErrorResponse("Room with ID '" + roomId + "' not found"))
                .build();
        }
        
        return Response.ok(room).build();
    }

    /**
     * Updates an existing room.
     * 
     * HTTP: PUT /api/v1/rooms/{roomId}
     * Request Body: JSON Room object with updated fields
     * Response: 200 OK with updated room, or 404 Not Found
     * 
     * @param roomId The ID of the room to update
     * @param updatedRoom The updated room data
     * @return The updated room
     */
    @PUT
    @Path("/{roomId}")
    public Response updateRoom(@PathParam("roomId") String roomId, Room updatedRoom) {
        // Validate input
        if (updatedRoom == null) {
            return Response.status(Response.Status.BAD_REQUEST)
                .entity(createErrorResponse("Request body cannot be null"))
                .build();
        }
        
        // Check if room exists
        Room existingRoom = roomService.getRoomById(roomId);
        if (existingRoom == null) {
            return Response.status(Response.Status.NOT_FOUND)
                .entity(createErrorResponse("Room with ID '" + roomId + "' not found"))
                .build();
        }
        
        // Preserve the ID from the path
        updatedRoom.setId(roomId);
        
        try {
            Room result = roomService.updateRoom(roomId, updatedRoom);
            
            Map<String, Object> response = new HashMap<>();
            response.put("message", "Room updated successfully");
            response.put("room", result);
            
            return Response.ok(response).build();
            
        } catch (IllegalArgumentException e) {
            return Response.status(Response.Status.BAD_REQUEST)
                .entity(createErrorResponse(e.getMessage()))
                .build();
        }
    }

    /**
     * Deletes a room from the system.
     * 
     * Business Rule: A room cannot be deleted if it still has sensors assigned.
     * This prevents data orphans and maintains referential integrity.
     * 
     * HTTP: DELETE /api/v1/rooms/{roomId}
     * Response: 
     *   - 204 No Content on success
     *   - 404 Not Found if room doesn't exist
     *   - 409 Conflict if room still has sensors
     * 
     * Idempotency: This operation is idempotent. Deleting a room that
     * doesn't exist returns 404. Deleting a room multiple times (after
     * successful deletion) returns 404 since the room no longer exists.
     * 
     * @param roomId The ID of the room to delete
     * @return 204 No Content on success
     */
    @DELETE
    @Path("/{roomId}")
    public Response deleteRoom(@PathParam("roomId") String roomId) {
        // Check if room exists first (for proper 404)
        Room room = roomService.getRoomById(roomId);
        if (room == null) {
            return Response.status(Response.Status.NOT_FOUND)
                .entity(createErrorResponse("Room with ID '" + roomId + "' not found"))
                .build();
        }
        
        try {
            // Attempt to delete - may throw RoomNotEmptyException (409)
            roomService.deleteRoom(roomId);
            
            // Success - return 204 No Content
            return Response.noContent().build();
            
        } catch (IllegalArgumentException e) {
            return Response.status(Response.Status.NOT_FOUND)
                .entity(createErrorResponse(e.getMessage()))
                .build();
        }
        // RoomNotEmptyException is handled by RoomNotEmptyExceptionMapper (409)
    }

    /**
     * Gets the count of rooms in the system.
     * 
     * HTTP: GET /api/v1/rooms/count
     * Response: 200 OK with count
     * 
     * @return Room count
     */
    @GET
    @Path("/count")
    public Response getRoomCount() {
        Map<String, Object> response = new HashMap<>();
        response.put("count", roomService.getRoomCount());
        
        return Response.ok(response).build();
    }

    /**
     * Helper method to create a standardized error response.
     * 
     * @param message The error message
     * @return Map containing error details
     */
    private Map<String, Object> createErrorResponse(String message) {
        Map<String, Object> error = new HashMap<>();
        error.put("error", "Bad Request");
        error.put("message", message);
        return error;
    }
}
