package com.smartcampus.resource;

import com.smartcampus.model.Sensor;
import com.smartcampus.model.SensorReading;
import com.smartcampus.service.SensorReadingService;
import com.smartcampus.service.SensorService;

import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Sensor Reading Resource - Manages readings for a specific sensor.
 * 
 * This resource is accessed via the sub-resource locator pattern from
 * SensorResource. It handles all operations related to sensor readings
 * at the path /api/v1/sensors/{sensorId}/readings
 * 
 * The sub-resource locator pattern allows us to:
 * 1. Keep reading-related logic separate from sensor logic
 * 2. Access the sensorId from the parent path
 * 3. Support deep nesting without massive controller classes
 * 4. Better organize code by concern
 * 
 * Endpoints:
 * - GET  /api/v1/sensors/{sensorId}/readings     - List all readings for sensor
 * - POST /api/v1/sensors/{sensorId}/readings     - Add a new reading
 * 
 * Business Rules:
 * - Cannot add readings to sensors in MAINTENANCE status (403 Forbidden)
 * - Adding a reading updates the sensor's currentValue
 * 
 * @author Ahmet Miah (W2071541)
 * @version 1.0
 */
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class SensorReadingResource {

    private final String sensorId;
    private final SensorService sensorService;
    private final SensorReadingService readingService;

    /**
     * Constructor for the sub-resource.
     * 
     * The sensorId is passed from the parent resource via the sub-resource
     * locator pattern. This gives us access to the sensor context for all
     * reading operations.
     * 
     * @param sensorId The ID of the sensor these readings belong to
     * @param sensorService The sensor service for validation and updates
     * @param readingService The reading service for data operations
     */
    public SensorReadingResource(String sensorId, 
                                  SensorService sensorService, 
                                  SensorReadingService readingService) {
        this.sensorId = sensorId;
        this.sensorService = sensorService;
        this.readingService = readingService;
    }

    /**
     * Retrieves all readings for this sensor.
     * 
     * HTTP: GET /api/v1/sensors/{sensorId}/readings
     * Response: 200 OK with list of readings, or 404 if sensor not found
     * 
     * @return List of readings for the sensor
     */
    @GET
    public Response getReadings() {
        // Verify the sensor exists
        Sensor sensor = sensorService.getSensorById(sensorId);
        if (sensor == null) {
            return Response.status(Response.Status.NOT_FOUND)
                .entity(createErrorResponse("Sensor with ID '" + sensorId + "' not found"))
                .build();
        }
        
        // Get all readings for this sensor
        List<SensorReading> readings = readingService.getReadingsForSensor(sensorId);
        
        // Calculate statistics
        double average = readingService.getAverageValue(sensorId);
        double[] minMax = readingService.getMinMaxValues(sensorId);
        
        // Build response with metadata
        Map<String, Object> response = new HashMap<>();
        response.put("sensorId", sensorId);
        response.put("count", readings.size());
        response.put("readings", readings);
        
        // Add statistics if readings exist
        if (!readings.isEmpty()) {
            Map<String, Double> stats = new HashMap<>();
            stats.put("average", average);
            stats.put("minimum", minMax[0]);
            stats.put("maximum", minMax[1]);
            response.put("statistics", stats);
        }
        
        return Response.ok(response).build();
    }

    /**
     * Adds a new reading for this sensor.
     * 
     * Business Rule: Cannot add readings to sensors in MAINTENANCE status.
     * This returns 403 Forbidden if attempted.
     * 
     * Side Effect: Updates the sensor's currentValue field.
     * 
     * HTTP: POST /api/v1/sensors/{sensorId}/readings
     * Request Body: JSON SensorReading object (value required)
     * Response: 201 Created with the new reading, or 400/403/404
     * 
     * @param reading The reading to add (value field required)
     * @return 201 Created with the new reading
     */
    @POST
    public Response addReading(SensorReading reading) {
        // Verify the sensor exists
        Sensor sensor = sensorService.getSensorById(sensorId);
        if (sensor == null) {
            return Response.status(Response.Status.NOT_FOUND)
                .entity(createErrorResponse("Sensor with ID '" + sensorId + "' not found"))
                .build();
        }
        
        // Validate input
        if (reading == null) {
            return Response.status(Response.Status.BAD_REQUEST)
                .entity(createErrorResponse("Request body cannot be null"))
                .build();
        }
        
        // Validate that value is provided (we'll accept 0 as a valid value)
        // Note: We can't easily check if value was explicitly set to 0 vs not provided
        // In a real system, we might use Optional or a wrapper class
        
        try {
            // Add the reading
            // SensorUnavailableException (403) may be thrown here if sensor is in MAINTENANCE
            SensorReading createdReading = readingService.addReading(sensorId, reading);
            
            // Get updated sensor for the response
            Sensor updatedSensor = sensorService.getSensorById(sensorId);
            
            // Build success response
            Map<String, Object> response = new HashMap<>();
            response.put("message", "Reading added successfully");
            response.put("reading", createdReading);
            response.put("sensorCurrentValue", updatedSensor.getCurrentValue());
            
            return Response.status(Response.Status.CREATED)
                .entity(response)
                .build();
                
        } catch (IllegalArgumentException e) {
            return Response.status(Response.Status.BAD_REQUEST)
                .entity(createErrorResponse(e.getMessage()))
                .build();
        }
        // SensorUnavailableException is handled by SensorUnavailableExceptionMapper (403)
    }

    /**
     * Gets the latest reading for this sensor.
     * 
     * HTTP: GET /api/v1/sensors/{sensorId}/readings/latest
     * Response: 200 OK with latest reading, or 404 if none exist
     * 
     * @return The most recent reading
     */
    @GET
    @Path("/latest")
    public Response getLatestReading() {
        // Verify the sensor exists
        Sensor sensor = sensorService.getSensorById(sensorId);
        if (sensor == null) {
            return Response.status(Response.Status.NOT_FOUND)
                .entity(createErrorResponse("Sensor with ID '" + sensorId + "' not found"))
                .build();
        }
        
        SensorReading latest = readingService.getLatestReading(sensorId);
        
        if (latest == null) {
            return Response.status(Response.Status.NOT_FOUND)
                .entity(createErrorResponse("No readings found for sensor '" + sensorId + "'"))
                .build();
        }
        
        Map<String, Object> response = new HashMap<>();
        response.put("sensorId", sensorId);
        response.put("reading", latest);
        
        return Response.ok(response).build();
    }

    /**
     * Gets reading statistics for this sensor.
     * 
     * HTTP: GET /api/v1/sensors/{sensorId}/readings/stats
     * Response: 200 OK with statistics
     * 
     * @return Statistics about the sensor's readings
     */
    @GET
    @Path("/stats")
    public Response getReadingStats() {
        // Verify the sensor exists
        Sensor sensor = sensorService.getSensorById(sensorId);
        if (sensor == null) {
            return Response.status(Response.Status.NOT_FOUND)
                .entity(createErrorResponse("Sensor with ID '" + sensorId + "' not found"))
                .build();
        }
        
        int count = readingService.getReadingCount(sensorId);
        double average = readingService.getAverageValue(sensorId);
        double[] minMax = readingService.getMinMaxValues(sensorId);
        
        Map<String, Object> stats = new HashMap<>();
        stats.put("sensorId", sensorId);
        stats.put("totalReadings", count);
        stats.put("averageValue", average);
        stats.put("minimumValue", minMax[0]);
        stats.put("maximumValue", minMax[1]);
        stats.put("currentValue", sensor.getCurrentValue());
        
        return Response.ok(stats).build();
    }

    /**
     * Deletes all readings for this sensor.
     * 
     * HTTP: DELETE /api/v1/sensors/{sensorId}/readings
     * Response: 204 No Content on success
     * 
     * @return 204 No Content
     */
    @DELETE
    public Response clearReadings() {
        // Verify the sensor exists
        Sensor sensor = sensorService.getSensorById(sensorId);
        if (sensor == null) {
            return Response.status(Response.Status.NOT_FOUND)
                .entity(createErrorResponse("Sensor with ID '" + sensorId + "' not found"))
                .build();
        }
        
        readingService.clearReadingsForSensor(sensorId);
        
        return Response.noContent().build();
    }

    /**
     * Helper method to create a standardized error response.
     * 
     * @param message The error message
     * @return Map containing error details
     */
    private Map<String, Object> createErrorResponse(String message) {
        Map<String, Object> error = new HashMap<>();
        error.put("error", "Bad Request");
        error.put("message", message);
        return error;
    }
}
