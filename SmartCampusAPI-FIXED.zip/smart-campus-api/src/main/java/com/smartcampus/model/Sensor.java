package com.smartcampus.model;

import java.util.Objects;

/**
 * Represents a Sensor in the Smart Campus system.
 * Sensors monitor various environmental conditions and are linked to specific rooms.
 * 
 * Each sensor has a unique ID, type (e.g., Temperature, CO2, Occupancy),
 * status (ACTIVE, MAINTENANCE, OFFLINE), current value, and a room ID
 * indicating its physical location.
 * 
 * @author Ahmet Miah (W2071541)
 * @version 1.0
 */
public class Sensor {

    /** Valid sensor status values */
    public static final String STATUS_ACTIVE = "ACTIVE";
    public static final String STATUS_MAINTENANCE = "MAINTENANCE";
    public static final String STATUS_OFFLINE = "OFFLINE";

    /** Valid sensor types */
    public static final String TYPE_TEMPERATURE = "Temperature";
    public static final String TYPE_CO2 = "CO2";
    public static final String TYPE_OCCUPANCY = "Occupancy";
    public static final String TYPE_HUMIDITY = "Humidity";
    public static final String TYPE_LIGHT = "Light";

    /** Unique identifier for the sensor, e.g., "TEMP-001" */
    private String id;
    
    /** Category of sensor, e.g., "Temperature", "Occupancy", "CO2" */
    private String type;
    
    /** Current state: "ACTIVE", "MAINTENANCE", or "OFFLINE" */
    private String status;
    
    /** The most recent measurement recorded by the hardware */
    private double currentValue;
    
    /** Foreign key linking to the Room where the sensor is located */
    private String roomId;

    /**
     * Default constructor - initializes with default values.
     * Required for JSON deserialization.
     */
    public Sensor() {
        this.status = STATUS_ACTIVE;
        this.currentValue = 0.0;
    }

    /**
     * Parameterized constructor for creating a Sensor instance.
     * 
     * @param id Unique sensor identifier
     * @param type Sensor type/category
     * @param status Current sensor status
     * @param currentValue Latest sensor reading
     * @param roomId ID of the room where sensor is located
     */
    public Sensor(String id, String type, String status, double currentValue, String roomId) {
        this.id = id;
        this.type = type;
        this.status = status != null ? status : STATUS_ACTIVE;
        this.currentValue = currentValue;
        this.roomId = roomId;
    }

    // ==================== GETTERS ====================

    public String getId() {
        return id;
    }

    public String getType() {
        return type;
    }

    public String getStatus() {
        return status;
    }

    public double getCurrentValue() {
        return currentValue;
    }

    public String getRoomId() {
        return roomId;
    }

    // ==================== SETTERS ====================

    public void setId(String id) {
        this.id = id;
    }

    public void setType(String type) {
        this.type = type;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public void setCurrentValue(double currentValue) {
        this.currentValue = currentValue;
    }

    public void setRoomId(String roomId) {
        this.roomId = roomId;
    }

    // ==================== HELPER METHODS ====================

    /**
     * Checks if the sensor is currently in maintenance mode.
     * Sensors in MAINTENANCE status cannot accept new readings.
     * 
     * @return true if sensor is in MAINTENANCE status
     */
    public boolean isInMaintenance() {
        return STATUS_MAINTENANCE.equalsIgnoreCase(status);
    }

    /**
     * Checks if the sensor is active and can accept readings.
     * 
     * @return true if sensor is ACTIVE
     */
    public boolean isActive() {
        return STATUS_ACTIVE.equalsIgnoreCase(status);
    }

    /**
     * Checks if the sensor is offline.
     * 
     * @return true if sensor is OFFLINE
     */
    public boolean isOffline() {
        return STATUS_OFFLINE.equalsIgnoreCase(status);
    }

    /**
     * Checks if the given type is a valid sensor type.
     * 
     * @param type the type to validate
     * @return true if valid, false otherwise
     */
    public static boolean isValidType(String type) {
        if (type == null) return false;
        return type.equalsIgnoreCase(TYPE_TEMPERATURE) ||
               type.equalsIgnoreCase(TYPE_CO2) ||
               type.equalsIgnoreCase(TYPE_OCCUPANCY) ||
               type.equalsIgnoreCase(TYPE_HUMIDITY) ||
               type.equalsIgnoreCase(TYPE_LIGHT);
    }

    /**
     * Checks if the given status is a valid sensor status.
     * 
     * @param status the status to validate
     * @return true if valid, false otherwise
     */
    public static boolean isValidStatus(String status) {
        if (status == null) return false;
        return status.equalsIgnoreCase(STATUS_ACTIVE) ||
               status.equalsIgnoreCase(STATUS_MAINTENANCE) ||
               status.equalsIgnoreCase(STATUS_OFFLINE);
    }

    // ==================== OBJECT METHODS ====================

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Sensor sensor = (Sensor) o;
        return Objects.equals(id, sensor.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

    @Override
    public String toString() {
        return "Sensor{" +
                "id='" + id + '\'' +
                ", type='" + type + '\'' +
                ", status='" + status + '\'' +
                ", currentValue=" + currentValue +
                ", roomId='" + roomId + '\'' +
                '}';
    }
}
