package com.smartcampus.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * Represents a Room in the Smart Campus system.
 * Each room has a unique ID, name, capacity, and a collection of sensor IDs.
 * 
 * This class follows the POJO pattern with proper encapsulation through
 * getters and setters, and includes proper equals/hashCode implementations
 * for reliable object comparison.
 * 
 * @author Ahmet Miah (W2071541)
 * @version 1.0
 */
public class Room {

    /** Unique identifier for the room, e.g., "LIB-301" */
    private String id;
    
    /** Human-readable name for the room, e.g., "Library Quiet Study" */
    private String name;
    
    /** Maximum occupancy for safety regulations */
    private int capacity;
    
    /** Collection of sensor IDs deployed in this room */
    private List<String> sensorIds;

    /**
     * Default constructor - initializes with empty sensor list.
     * Required for JSON deserialization.
     */
    public Room() {
        this.sensorIds = new ArrayList<>();
    }

    /**
     * Parameterized constructor for creating a complete Room instance.
     * 
     * @param id Unique room identifier
     * @param name Human-readable room name
     * @param capacity Maximum room capacity
     */
    public Room(String id, String name, int capacity) {
        this.id = id;
        this.name = name;
        this.capacity = capacity;
        this.sensorIds = new ArrayList<>();
    }

    /**
     * Full constructor including sensor list.
     * 
     * @param id Unique room identifier
     * @param name Human-readable room name
     * @param capacity Maximum room capacity
     * @param sensorIds List of sensor IDs in this room
     */
    public Room(String id, String name, int capacity, List<String> sensorIds) {
        this.id = id;
        this.name = name;
        this.capacity = capacity;
        this.sensorIds = sensorIds != null ? new ArrayList<>(sensorIds) : new ArrayList<>();
    }

    // ==================== GETTERS ====================

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public int getCapacity() {
        return capacity;
    }

    public List<String> getSensorIds() {
        // Return a copy to maintain encapsulation and prevent external modification
        return new ArrayList<>(sensorIds);
    }

    // ==================== SETTERS ====================

    public void setId(String id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }

    public void setSensorIds(List<String> sensorIds) {
        this.sensorIds = sensorIds != null ? new ArrayList<>(sensorIds) : new ArrayList<>();
    }

    // ==================== HELPER METHODS ====================

    /**
     * Adds a sensor ID to this room's collection.
     * Thread-safe operation - should be called within synchronized context.
     * 
     * @param sensorId The sensor ID to add
     * @return true if added successfully, false if already present
     */
    public boolean addSensorId(String sensorId) {
        if (!sensorIds.contains(sensorId)) {
            return sensorIds.add(sensorId);
        }
        return false;
    }

    /**
     * Removes a sensor ID from this room's collection.
     * Thread-safe operation - should be called within synchronized context.
     * 
     * @param sensorId The sensor ID to remove
     * @return true if removed successfully, false if not found
     */
    public boolean removeSensorId(String sensorId) {
        return sensorIds.remove(sensorId);
    }

    /**
     * Checks if this room has any sensors assigned.
     * 
     * @return true if sensors are present, false otherwise
     */
    public boolean hasSensors() {
        return !sensorIds.isEmpty();
    }

    /**
     * Gets the count of sensors in this room.
     * 
     * @return number of sensors
     */
    public int getSensorCount() {
        return sensorIds.size();
    }

    // ==================== OBJECT METHODS ====================

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Room room = (Room) o;
        return Objects.equals(id, room.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

    @Override
    public String toString() {
        return "Room{" +
                "id='" + id + '\'' +
                ", name='" + name + '\'' +
                ", capacity=" + capacity +
                ", sensorCount=" + sensorIds.size() +
                '}';
    }
}
