package com.smartcampus.model;

import java.util.Objects;
import java.util.UUID;

/**
 * Represents a single sensor reading event in the Smart Campus system.
 * Each reading has a unique ID, timestamp, and value.
 * 
 * Readings are stored as historical data for each sensor and can be used
 * for trend analysis, reporting, and monitoring.
 * 
 * @author Ahmet Miah (W2071541)
 * @version 1.0
 */
public class SensorReading {

    /** Unique reading event ID (UUID recommended) */
    private String id;
    
    /** Epoch time (milliseconds) when the reading was captured */
    private long timestamp;
    
    /** The actual metric value recorded by the hardware */
    private double value;

    /**
     * Default constructor - generates a new UUID and sets current timestamp.
     * Required for JSON deserialization.
     */
    public SensorReading() {
        this.id = UUID.randomUUID().toString();
        this.timestamp = System.currentTimeMillis();
    }

    /**
     * Constructor for creating a reading with specific value.
     * Automatically generates ID and timestamp.
     * 
     * @param value The sensor value to record
     */
    public SensorReading(double value) {
        this.id = UUID.randomUUID().toString();
        this.timestamp = System.currentTimeMillis();
        this.value = value;
    }

    /**
     * Full parameterized constructor for complete control.
     * 
     * @param id Unique reading ID
     * @param timestamp Epoch timestamp in milliseconds
     * @param value The sensor reading value
     */
    public SensorReading(String id, long timestamp, double value) {
        this.id = id;
        this.timestamp = timestamp;
        this.value = value;
    }

    // ==================== GETTERS ====================

    public String getId() {
        return id;
    }

    public long getTimestamp() {
        return timestamp;
    }

    public double getValue() {
        return value;
    }

    // ==================== SETTERS ====================

    public void setId(String id) {
        this.id = id;
    }

    public void setTimestamp(long timestamp) {
        this.timestamp = timestamp;
    }

    public void setValue(double value) {
        this.value = value;
    }

    // ==================== HELPER METHODS ====================

    /**
     * Gets a human-readable formatted timestamp.
     * 
     * @return Formatted date/time string
     */
    public String getFormattedTimestamp() {
        java.time.Instant instant = java.time.Instant.ofEpochMilli(timestamp);
        return instant.toString();
    }

    /**
     * Gets the age of this reading in milliseconds.
     * 
     * @return age in milliseconds
     */
    public long getAgeMillis() {
        return System.currentTimeMillis() - timestamp;
    }

    /**
     * Checks if this reading is older than the specified duration.
     * 
     * @param durationMillis duration in milliseconds
     * @return true if reading is older
     */
    public boolean isOlderThan(long durationMillis) {
        return getAgeMillis() > durationMillis;
    }

    // ==================== OBJECT METHODS ====================

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        SensorReading that = (SensorReading) o;
        return Objects.equals(id, that.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

    @Override
    public String toString() {
        return "SensorReading{" +
                "id='" + id + '\'' +
                ", timestamp=" + timestamp +
                " (" + getFormattedTimestamp() + ")" +
                ", value=" + value +
                '}';
    }
}
