package com.smartcampus.filter;

import jakarta.ws.rs.container.ContainerRequestContext;
import jakarta.ws.rs.container.ContainerRequestFilter;
import jakarta.ws.rs.container.ContainerResponseContext;
import jakarta.ws.rs.container.ContainerResponseFilter;
import jakarta.ws.rs.ext.Provider;
import java.io.IOException;
import java.time.Duration;
import java.time.Instant;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Logging Filter - Provides API observability through request/response logging.
 * 
 * This filter implements both ContainerRequestFilter and ContainerResponseFilter
 * to log details about every incoming request and outgoing response. This enables
 * monitoring, debugging, and auditing of API usage.
 * 
 * What gets logged:
 * - HTTP method (GET, POST, PUT, DELETE, etc.)
 * - Request URI (the full path being accessed)
 * - Response status code
 * - Request duration (time taken to process)
 * - Timestamp of the request
 * 
 * Benefits of using JAX-RS filters for logging:
 * 1. Centralized logging - all requests logged consistently
 * 2. No code duplication - don't need Logger statements in every resource method
 * 3. Automatic coverage - all endpoints are logged without manual effort
 * 4. Cross-cutting concern - logging is separated from business logic
 * 5. Easy to enable/disable - can be removed or modified in one place
 * 
 * The filter is annotated with @Provider so JAX-RS automatically discovers
 * and registers it.
 * 
 * @author Ahmet Miah (W2071541)
 * @version 1.0
 */
@Provider
public class LoggingFilter implements ContainerRequestFilter, ContainerResponseFilter {

    private static final Logger LOGGER = Logger.getLogger(LoggingFilter.class.getName());
    
    // Attribute key for storing request start time
    private static final String REQUEST_START_TIME = "requestStartTime";

    /**
     * Logs incoming requests.
     * 
     * This method is called BEFORE the request is processed by the resource.
     * It logs the HTTP method and URI, and stores the start time for
     * calculating request duration.
     * 
     * @param requestContext The request context containing request details
     * @throws IOException if an I/O error occurs
     */
    @Override
    public void filter(ContainerRequestContext requestContext) throws IOException {
        // Record the start time for duration calculation
        requestContext.setProperty(REQUEST_START_TIME, Instant.now());
        
        // Extract request details
        String method = requestContext.getMethod();
        String uri = requestContext.getUriInfo().getRequestUri().toString();
        String path = requestContext.getUriInfo().getPath();
        
        // Log the incoming request
        LOGGER.log(Level.INFO, 
            "[REQUEST] {0} {1} | Path: /{2}",
            new Object[]{method, uri, path});
        
        // Additional logging for debugging (optional)
        if (LOGGER.isLoggable(Level.FINE)) {
            LOGGER.log(Level.FINE, 
                "Request Headers: {0}",
                requestContext.getHeaders());
        }
    }

    /**
     * Logs outgoing responses.
     * 
     * This method is called AFTER the request has been processed by the resource.
     * It logs the response status code and calculates the request duration.
     * 
     * @param requestContext The request context
     * @param responseContext The response context containing response details
     * @throws IOException if an I/O error occurs
     */
    @Override
    public void filter(ContainerRequestContext requestContext, 
                       ContainerResponseContext responseContext) throws IOException {
        // Calculate request duration
        Instant startTime = (Instant) requestContext.getProperty(REQUEST_START_TIME);
        long durationMs = 0;
        if (startTime != null) {
            durationMs = Duration.between(startTime, Instant.now()).toMillis();
        }
        
        // Extract request and response details
        String method = requestContext.getMethod();
        String path = requestContext.getUriInfo().getPath();
        int statusCode = responseContext.getStatus();
        String statusReason = getStatusReason(statusCode);
        
        // Determine log level based on status code
        Level logLevel = Level.INFO;
        if (statusCode >= 400 && statusCode < 500) {
            logLevel = Level.WARNING; // Client errors
        } else if (statusCode >= 500) {
            logLevel = Level.SEVERE;  // Server errors
        }
        
        // Log the response
        LOGGER.log(logLevel,
            "[RESPONSE] {0} /{1} | Status: {2} {3} | Duration: {4}ms",
            new Object[]{method, path, statusCode, statusReason, durationMs});
        
        // Additional logging for debugging (optional)
        if (LOGGER.isLoggable(Level.FINE)) {
            LOGGER.log(Level.FINE,
                "Response Headers: {0}",
                responseContext.getHeaders());
        }
    }

    /**
     * Gets a human-readable reason phrase for HTTP status codes.
     * 
     * @param statusCode The HTTP status code
     * @return The reason phrase
     */
    private String getStatusReason(int statusCode) {
        switch (statusCode) {
            case 200: return "OK";
            case 201: return "Created";
            case 204: return "No Content";
            case 400: return "Bad Request";
            case 401: return "Unauthorized";
            case 403: return "Forbidden";
            case 404: return "Not Found";
            case 409: return "Conflict";
            case 422: return "Unprocessable Entity";
            case 500: return "Internal Server Error";
            default: return "";
        }
    }
}
